package info.hoang8f.fbutton.demo;

/**
 * Created by hoang8f on 5/10/14.
 */
public class Config {

    public static final String GITHUB_URL = "https://github.com/hoang8f/android-flat-button";

}
